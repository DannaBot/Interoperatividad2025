<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="libro.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet">    
    <title>Blog: Los mejores restaurantes</title>
</head>

<body>
<header>
    <nav id="nav">
        <img src="logo.png" alt="LOGO" class="logo" id="logo">
        <h1>Blog: Los mejores restaurantes</h1>
        <ul class="menu">
            <li><a href="#ContenedorForm">Comentarios</a></li>
        </ul>
    </nav>
</header>

<div class="contenedorC">
    <img src="caption.jpg" alt="CAPTION" class="captionImg">
</div>

<h1 id="h11">Espacio libre para opinar</h1>
<p id="pp">Deja tus mejores recomendaciones o... las peores​​</p>

<?php
$archivo = 'datos.txt';
$contadorArchivo = 'contador.txt';
$palabrasProhibidas = ["mensos", "tontos", "estupido", "inutil", "asqueroso"];

//Contador de visitas
if (!file_exists($contadorArchivo)) file_put_contents($contadorArchivo, "0");
$contador = (int) file_get_contents($contadorArchivo) + 1;
file_put_contents($contadorArchivo, $contador);

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["Nombre"], $_POST["Comentario"])) {
    $nombre = trim($_POST["Nombre"]);
    $comentario = trim($_POST["Comentario"]);
    
    //Palabras prohibidas
    foreach ($palabrasProhibidas as $palabra) {
        if (stripos($comentario, $palabra) !== false) {
            echo "<p class='error'>Error: Tu comentario contiene palabras prohibidas.</p>";
            exit();
        }
    }
    
    if (!empty($nombre) && !empty($comentario)) {
        $idComentario = uniqid();
        $fechaHora = date("d M, Y - h:i A");
        $linea = "ID: $idComentario | [$fechaHora] | $nombre | $comentario\n";
        file_put_contents($archivo, $linea, FILE_APPEND);
        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    }
}

// Procesar respuestas a comentarios
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["respuesta"], $_POST["idComentario"], $_POST["nombreRespuesta"])) {
    $idComentarioPadre = trim($_POST["idComentario"]);
    $nombreRespuesta = trim($_POST["nombreRespuesta"]);
    $respuesta = trim($_POST["respuesta"]);
    
    if (!empty($nombreRespuesta) && !empty($respuesta)) {
        $fechaHoraRespuesta = date("d M, Y - h:i A");
        $respuestaArchivo = 'respuestas_'.$idComentarioPadre.'.txt';
        $lineaRespuesta = "[$fechaHoraRespuesta] | $nombreRespuesta | $respuesta\n";
        file_put_contents($respuestaArchivo, $lineaRespuesta, FILE_APPEND);
        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    }
}

// Borrar todos los comentarios
if (isset($_POST['borrar'])) {
    file_put_contents($archivo, "");
    foreach (glob("respuestas_*.txt") as $archivoRespuesta) {
        unlink($archivoRespuesta);
    }
    echo "<p class='mensaje'>Comentarios eliminados correctamente.</p>";
}

// Procesar búsqueda de comentarios
$busqueda = isset($_GET['busqueda']) ? trim($_GET['busqueda']) : '';
$mostrarResultadosBusqueda = !empty($busqueda);
?>

<section class="contenedorForm" id="ContenedorForm">
    <div class="form">
        <form method="POST">
            <p>Ingresa tu nombre:</p>
            <input type="text" name="Nombre" required maxlength="10"><br>
            <p>Ingresa tu comentario:</p>
            <textarea name="Comentario" required maxlength="100"></textarea><br><br>
            <input type="submit" value="Subir">
        </form>
    </div>
</section>

<section class="buscar-comentarios">
    <h2>Buscar comentarios</h2>
    <form method="GET">
        <input type="text" name="busqueda" placeholder="Buscar en comentarios..." value="<?php echo htmlspecialchars($busqueda); ?>">
        <input type="submit" value="Buscar">
        <?php if ($mostrarResultadosBusqueda): ?>
            <a href="?" class="cancelar-busqueda">Mostrar todos</a>
        <?php endif; ?>
    </form>
</section>

<?php if ($mostrarResultadosBusqueda): ?>
    <section class="resultados-busqueda">
        <h3>Resultados de búsqueda para: "<?php echo htmlspecialchars($busqueda); ?>"</h3>
        <?php
        $encontrados = 0;
        if (file_exists($archivo)) {
            $contenido = file($archivo, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $contenido = array_reverse($contenido);
            
            foreach ($contenido as $linea) {
                $partes = explode('|', $linea);
                if (count($partes) < 4) continue;
                
                $idComentario = trim($partes[0]);
                $fechaHora = trim($partes[1]);
                $nombre = trim($partes[2]);
                $comentario = trim($partes[3]);
                
                // Buscar coincidencia en el comentario principal
                if (stripos($comentario, $busqueda) !== false) {
                    $encontrados++;
                    echo "<div class='comentario-padre'>";
                    echo "<div class='cabecera-comentario'>";
                    echo "<span class='fecha'>$fechaHora</span>";
                    echo "<span class='nombre'>$nombre</span>";
                    echo "</div>";
                    echo "<p class='texto-comentario'>$comentario</p>";
                    
                    // Mostrar respuestas a este comentario
                    $respuestasArchivo = 'respuestas_'.str_replace('ID: ', '', $idComentario).'.txt';
                    if (file_exists($respuestasArchivo)) {
                        $respuestas = file($respuestasArchivo, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                        if (!empty($respuestas)) {
                            echo "<div class='contenedor-respuestas'>";
                            foreach ($respuestas as $respuesta) {
                                $partesRespuesta = explode('|', $respuesta);
                                if (count($partesRespuesta) >= 3) {
                                    $fechaRespuesta = trim($partesRespuesta[0]);
                                    $nombreRespuesta = trim($partesRespuesta[1]);
                                    $textoRespuesta = trim($partesRespuesta[2]);
                                    
                                    echo "<div class='respuesta'>";
                                    echo "<div class='cabecera-respuesta'>";
                                    echo "<span class='fecha'>$fechaRespuesta</span>";
                                    echo "<span class='nombre'>$nombreRespuesta</span>";
                                    echo "</div>";
                                    echo "<p class='texto-respuesta'>$textoRespuesta</p>";
                                    echo "</div>";
                                }
                            }
                            echo "</div>";
                        }
                    }
                    
                    echo "</div>"; // Cierre de comentario-padre
                }
            }
        }
        
        if ($encontrados === 0) {
            echo "<p class='sin-resultados'>No se encontraron comentarios que coincidan con tu búsqueda.</p>";
        }
        ?>
    </section>
<?php else: ?>
    <section class="comentarios">
        <h2>Comentarios</h2>
        <div id="coments">
        <?php
        // Configuración de paginación
        $comentariosPorPagina = 5;
        $pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
        $inicio = ($pagina - 1) * $comentariosPorPagina;
        
        if (file_exists($archivo)) {
            $contenido = file($archivo, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $contenido = array_reverse($contenido);
            $totalPaginas = ceil(count($contenido) / $comentariosPorPagina);
            $comentariosPagina = array_slice($contenido, $inicio, $comentariosPorPagina);
            
            foreach ($comentariosPagina as $linea) {
                $partes = explode('|', $linea);
                if (count($partes) < 4) continue;
                
                $idComentario = trim($partes[0]);
                $fechaHora = trim($partes[1]);
                $nombre = trim($partes[2]);
                $comentario = trim($partes[3]);
                
                // Mostrar comentario principal
                echo "<div class='comentario-padre'>";
                echo "<div class='cabecera-comentario'>";
                echo "<span class='fecha'>$fechaHora</span>";
                echo "<span class='nombre'>$nombre</span>";
                echo "</div>";
                echo "<p class='texto-comentario'>$comentario</p>";
                
                // Mostrar respuestas existentes
                $respuestasArchivo = 'respuestas_'.str_replace('ID: ', '', $idComentario).'.txt';
                if (file_exists($respuestasArchivo)) {
                    $respuestas = file($respuestasArchivo, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                    if (!empty($respuestas)) {
                        echo "<div class='contenedor-respuestas'>";
                        foreach ($respuestas as $respuesta) {
                            $partesRespuesta = explode('|', $respuesta);
                            if (count($partesRespuesta) >= 3) {
                                $fechaRespuesta = trim($partesRespuesta[0]);
                                $nombreRespuesta = trim($partesRespuesta[1]);
                                $textoRespuesta = trim($partesRespuesta[2]);
                                
                                echo "<div class='respuesta'>";
                                echo "<div class='cabecera-respuesta'>";
                                echo "<span class='fecha'>$fechaRespuesta</span>";
                                echo "<span class='nombre'>$nombreRespuesta</span>";
                                echo "</div>";
                                echo "<p class='texto-respuesta'>$textoRespuesta</p>";
                                echo "</div>";
                            }
                        }
                        echo "</div>";
                    }
                }
                
                // Formulario para responder
                echo "<div class='contenedor-res'>";
                echo "<form method='POST' class='form-respuesta'>";
                echo "<input type='hidden' name='idComentario' value='".str_replace('ID: ', '', $idComentario)."'>";
                echo "<input type='text' name='nombreRespuesta' placeholder='Tu nombre' required maxlength='10'>";
                echo "<textarea name='respuesta' placeholder='Tu respuesta...' required maxlength='100'></textarea>";
                echo "<input type='submit' value='Responder'>";
                echo "</form>";
                echo "</div>";
                
                echo "</div>"; // Cierre de comentario-padre
            }
            
            // Paginación
            if ($totalPaginas > 1) {
                echo "<div class='paginacion'>";
                if ($pagina > 1) {
                    echo "<a href='?pagina=".($pagina - 1)."' class='pagina-anterior'>Anterior</a> ";
                }
                
                for ($i = 1; $i <= $totalPaginas; $i++) {
                    if ($i == $pagina) {
                        echo "<span class='pagina-actual'>$i</span> ";
                    } else {
                        echo "<a href='?pagina=$i'>$i</a> ";
                    }
                }
                
                if ($pagina < $totalPaginas) {
                    echo "<a href='?pagina=".($pagina + 1)."' class='pagina-siguiente'>Siguiente</a>";
                }
                echo "</div>";
            }
        } else {
            echo "<p class='sin-comentarios'>No hay comentarios aún.</p>";
        }
        ?>
        </div>
    </section>
<?php endif; ?>

<!-- Botón de borrar todos los comentarios -->
<section class="borrar-comentarios">
    <form method="POST">
        <input type="submit" name="borrar" value="Eliminar todos los comentarios" onclick="return confirm('¿Estás seguro de eliminar todos los comentarios?');">
    </form>
</section>

<footer>
    <p>Danna Lisseth Martínez Monterrubio</p>
    <p>Visitas: <?php echo $contador; ?></p>
</footer>
</body>
</html>